import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Bot, User, Brain, BarChart3, HeartPulse, Waves, Timer, 
  Moon, Sun, CloudRain, Wind, Music, Volume2, Calendar, Clock,
  UserCircle, Settings, Activity, ThumbsUp, ThumbsDown, Smile, Frown
} from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { format, addMinutes, subDays } from 'date-fns';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
);

interface UserProfile {
  id: string;
  name: string;
  preferredInterventions: string[];
  stressHistory: {
    date: Date;
    level: number;
    triggers: string[];
  }[];
  completedExercises: {
    date: Date;
    type: string;
    duration: number;
    feedback: number;
  }[];
}

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'assessment' | 'exercise' | 'chart' | 'meditation' | 'ambient' | 'feedback';
  exerciseType?: 'breathing' | 'meditation' | 'mindfulness' | 'progressive-relaxation';
  duration?: number;
  ambientSound?: 'rain' | 'waves' | 'whitenoise' | 'forest';
  feedback?: {
    effectiveness: number;
    mood: 'better' | 'same' | 'worse';
    notes?: string;
  };
}

interface StressData {
  date: Date;
  level: number;
  mood?: 'happy' | 'neutral' | 'sad' | 'anxious' | 'calm';
  triggers?: string[];
  interventions?: string[];
  effectiveness?: number;
}

interface Exercise {
  id: string;
  name: string;
  duration: number;
  type: 'breathing' | 'meditation' | 'mindfulness' | 'progressive-relaxation';
  description: string;
  steps: string[];
  recommendedFor: {
    stressLevel: [number, number];
    timeOfDay?: ('morning' | 'afternoon' | 'evening' | 'night')[];
    duration: number;
  };
}

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your AI Stress Management Assistant. I can help you with:\n\n• Stress Assessment\n• Guided Meditation\n• Breathing Exercises\n• Progressive Relaxation\n• Mood Tracking\n• Ambient Sounds\n\nLet's start by creating your profile. What's your name?",
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [stressData, setStressData] = useState<StressData[]>([]);
  const [isAssessing, setIsAssessing] = useState(false);
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null);
  const [exerciseTimer, setExerciseTimer] = useState<number | null>(null);
  const [ambientSound, setAmbientSound] = useState<string | null>(null);
  const [timeOfDay, setTimeOfDay] = useState<'morning' | 'afternoon' | 'evening' | 'night'>('morning');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const exercises: Exercise[] = [
    {
      id: 'box-breathing',
      name: 'Box Breathing',
      duration: 240,
      type: 'breathing',
      description: 'A Navy SEAL technique for stress management',
      steps: [
        'Inhale for 4 counts',
        'Hold for 4 counts',
        'Exhale for 4 counts',
        'Hold for 4 counts'
      ],
      recommendedFor: {
        stressLevel: [7, 10],
        timeOfDay: ['morning', 'afternoon'],
        duration: 4
      }
    },
    {
      id: 'body-scan',
      name: 'Body Scan Meditation',
      duration: 300,
      type: 'meditation',
      description: 'Progressive relaxation from head to toe',
      steps: [
        'Find a comfortable position',
        'Close your eyes',
        'Focus on your breath',
        'Scan your body from head to toe',
        'Release tension in each area'
      ],
      recommendedFor: {
        stressLevel: [4, 7],
        timeOfDay: ['evening', 'night'],
        duration: 5
      }
    },
    {
      id: 'progressive-relaxation',
      name: 'Progressive Muscle Relaxation',
      duration: 360,
      type: 'progressive-relaxation',
      steps: [
        'Tense and relax your feet',
        'Move to your calves',
        'Progress to your thighs',
        'Continue with your abdomen',
        'Finally reach your shoulders and face'
      ],
      recommendedFor: {
        stressLevel: [5, 8],
        timeOfDay: ['evening'],
        duration: 6
      }
    },
    {
      id: 'mindful-breathing',
      name: 'Mindful Breathing',
      duration: 180,
      type: 'meditation',
      description: 'Focus on your breath to center yourself',
      steps: [
        'Sit comfortably',
        'Close your eyes',
        'Focus on your natural breath',
        'Notice any thoughts without judgment',
        'Return focus to your breath'
      ],
      recommendedFor: {
        stressLevel: [3, 6],
        timeOfDay: ['morning', 'afternoon'],
        duration: 3
      }
    }
  ];

  const ambientSounds = [
    { id: 'rain', name: 'Rainfall', icon: CloudRain },
    { id: 'waves', name: 'Ocean Waves', icon: Waves },
    { id: 'whitenoise', name: 'White Noise', icon: Volume2 },
    { id: 'forest', name: 'Forest Sounds', icon: Wind }
  ];

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) setTimeOfDay('morning');
    else if (hour >= 12 && hour < 17) setTimeOfDay('afternoon');
    else if (hour >= 17 && hour < 22) setTimeOfDay('evening');
    else setTimeOfDay('night');
  }, []);

  useEffect(() => {
    if (exerciseTimer && exerciseTimer > 0) {
      const timer = setTimeout(() => {
        setExerciseTimer(exerciseTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (exerciseTimer === 0) {
      setCurrentExercise(null);
      requestExerciseFeedback();
    }
  }, [exerciseTimer]);

  const requestExerciseFeedback = () => {
    setMessages(prev => [...prev, {
      id: prev.length + 1,
      text: "How effective was this exercise in reducing your stress?\n\n1 - Not at all effective\n2 - Slightly effective\n3 - Moderately effective\n4 - Very effective\n5 - Extremely effective",
      sender: 'bot',
      timestamp: new Date(),
      type: 'feedback'
    }]);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Generate realistic looking stress data
    const mockData: StressData[] = Array.from({ length: 14 }).map((_, i) => {
      const date = subDays(new Date(), 13 - i);
      const baseLevel = 5; // Base stress level
      const dayVariation = Math.sin(i * 0.5) * 2; // Creates a wave pattern
      const randomVariation = (Math.random() - 0.5) * 2; // Adds some randomness
      
      let level = Math.round(baseLevel + dayVariation + randomVariation);
      level = Math.max(1, Math.min(10, level)); // Ensure between 1 and 10
      
      const moods: StressData['mood'][] = ['happy', 'neutral', 'sad', 'anxious', 'calm'];
      const triggers = [
        'work deadlines',
        'relationship issues',
        'financial concerns',
        'health worries',
        'sleep problems',
        'family responsibilities'
      ];
      
      return {
        date,
        level,
        mood: moods[Math.floor(Math.random() * moods.length)],
        triggers: [triggers[Math.floor(Math.random() * triggers.length)]],
        interventions: level > 7 ? ['breathing', 'meditation'] : ['meditation'],
        effectiveness: Math.random() * 5
      };
    });
    
    setStressData(mockData);
  }, []);

  const chartData = {
    labels: stressData.map(d => format(d.date, 'MMM d')),
    datasets: [
      {
        label: 'Stress Level',
        data: stressData.map(d => d.level),
        borderColor: 'rgb(79, 70, 229)',
        backgroundColor: 'rgba(79, 70, 229, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Intervention Effectiveness',
        data: stressData.map(d => d.effectiveness || null),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        tension: 0.4,
        fill: true,
      }
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Stress Levels & Intervention Effectiveness',
      },
    },
    scales: {
      y: {
        min: 0,
        max: 10,
        title: {
          display: true,
          text: 'Level',
        },
      },
    },
  };

  const getRecommendedExercise = (stressLevel: number): Exercise => {
    const timeAppropriate = exercises.filter(ex => 
      (!ex.recommendedFor.timeOfDay || ex.recommendedFor.timeOfDay.includes(timeOfDay)) &&
      stressLevel >= ex.recommendedFor.stressLevel[0] &&
      stressLevel <= ex.recommendedFor.stressLevel[1]
    );

    if (timeAppropriate.length === 0) return exercises[0];
    return timeAppropriate[Math.floor(Math.random() * timeAppropriate.length)];
  };

  const startExercise = (exercise: Exercise) => {
    setCurrentExercise(exercise);
    setExerciseTimer(exercise.duration);
    setMessages(prev => [...prev, {
      id: prev.length + 1,
      text: `Let's begin ${exercise.name}.\n\n${exercise.description}\n\nFollow these steps:\n${exercise.steps.map((step, i) => `${i + 1}. ${step}`).join('\n')}`,
      sender: 'bot',
      timestamp: new Date(),
      type: 'exercise',
      exerciseType: exercise.type,
      duration: exercise.duration,
    }]);
  };

  const toggleAmbientSound = (soundId: string) => {
    if (ambientSound === soundId) {
      setAmbientSound(null);
    } else {
      setAmbientSound(soundId);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');

    // Simulate AI processing delay
    setTimeout(() => {
      let botResponse: Message;

      if (!userProfile) {
        // Profile creation flow
        setUserProfile({
          id: Math.random().toString(36).substr(2, 9),
          name: inputMessage,
          preferredInterventions: [],
          stressHistory: [],
          completedExercises: []
        });
        
        botResponse = {
          id: messages.length + 2,
          text: `Nice to meet you, ${inputMessage}! Let's start by assessing your current stress level. On a scale of 1-10, how would you rate your stress right now?`,
          sender: 'bot',
          timestamp: new Date(),
          type: 'assessment'
        };
        setIsAssessing(true);
      } else if (isAssessing) {
        const stressLevel = parseInt(inputMessage);
        if (!isNaN(stressLevel) && stressLevel >= 1 && stressLevel <= 10) {
          setIsAssessing(false);
          setStressData(prev => [...prev, { 
            date: new Date(), 
            level: stressLevel,
            mood: 'neutral'
          }]);
          
          const recommendedExercise = getRecommendedExercise(stressLevel);
          botResponse = {
            id: messages.length + 2,
            text: `Based on your stress level of ${stressLevel}, I recommend ${recommendedExercise.name}. It's particularly effective during the ${timeOfDay} and takes ${recommendedExercise.duration / 60} minutes. Would you like to try it?`,
            sender: 'bot',
            timestamp: new Date(),
            type: 'exercise',
            exerciseType: recommendedExercise.type,
            duration: recommendedExercise.duration,
          };
        } else {
          botResponse = {
            id: messages.length + 2,
            text: "Please provide a number between 1 and 10 to rate your stress level.",
            sender: 'bot',
            timestamp: new Date(),
          };
        }
      } else if (messages[messages.length - 2].type === 'feedback') {
        const rating = parseInt(inputMessage);
        if (!isNaN(rating) && rating >= 1 && rating <= 5) {
          botResponse = {
            id: messages.length + 2,
            text: `Thank you for your feedback! I'll use this to better personalize future recommendations. Would you like to:\n\n1. Try another exercise\n2. View your progress\n3. Listen to ambient sounds`,
            sender: 'bot',
            timestamp: new Date(),
          };
        } else {
          botResponse = {
            id: messages.length + 2,
            text: "Please rate the effectiveness from 1 to 5.",
            sender: 'bot',
            timestamp: new Date(),
            type: 'feedback'
          };
        }
      } else if (inputMessage.toLowerCase().includes('yes') && messages[messages.length - 2].type === 'exercise') {
        const exercise = exercises.find(ex => ex.type === messages[messages.length - 2].exerciseType) || exercises[0];
        startExercise(exercise);
        return;
      } else {
        const keywords = inputMessage.toLowerCase();
        if (keywords.includes('meditation') || keywords.includes('meditate')) {
          botResponse = {
            id: messages.length + 2,
            text: "I can guide you through several meditation practices:\n\n1. Body Scan Meditation (5 min)\n2. Mindful Breathing (3 min)\n3. Loving-Kindness Meditation (10 min)\n\nWhich would you like to try?",
            sender: 'bot',
            timestamp: new Date(),
            type: 'meditation',
          };
        } else if (keywords.includes('sound') || keywords.includes('ambient')) {
          botResponse = {
            id: messages.length + 2,
            text: "I can play calming ambient sounds to help you relax. Choose from:\n• Rainfall\n• Ocean Waves\n• White Noise\n• Forest Sounds",
            sender: 'bot',
            timestamp: new Date(),
            type: 'ambient',
          };
        } else if (keywords.includes('stress') || keywords.includes('anxious')) {
          botResponse = {
            id: messages.length + 2,
            text: "I understand you're feeling stressed. Let's check your current stress level. On a scale of 1-10, how would you rate your stress right now?",
            sender: 'bot',
            timestamp: new Date(),
            type: 'assessment',
          };
          setIsAssessing(true);
        } else {
          botResponse = {
            id: messages.length + 2,
            text: "I'm here to help you manage stress. Would you like to:\n1. Take a stress assessment\n2. Try a breathing exercise\n3. Start a meditation session\n4. Listen to ambient sounds\n5. Track your mood\n6. View your progress",
            sender: 'bot',
            timestamp: new Date(),
          };
        }
      }

      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-3 h-[600px]">
          {/* Sidebar */}
          <div className="hidden md:block bg-indigo-50 border-r border-gray-200 p-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-indigo-900">Wellness Dashboard</h2>
              {timeOfDay === 'morning' || timeOfDay === 'afternoon' ? (
                <Sun className="w-5 h-5 text-indigo-600" />
              ) : (
                <Moon className="w-5 h-5 text-indigo-600" />
              )}
            </div>

            {/* User Profile Summary */}
            {userProfile && (
              <div className="mb-6 bg-white rounded-lg p-4 shadow-sm">
                <div className="flex items-center gap-3 mb-2">
                  <UserCircle className="w-8 h-8 text-indigo-600" />
                  <div>
                    <h3 className="font-medium text-indigo-900">{userProfile.name}</h3>
                    <p className="text-sm text-indigo-600">Member since {format(new Date(), 'MMM d, yyyy')}</p>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div className="bg-indigo-50 p-2 rounded">
                    <p className="text-indigo-900">Exercises</p>
                    <p className="font-medium">{userProfile.completedExercises.length}</p>
                  </div>
                  <div className="bg-indigo-50 p-2 rounded">
                    <p className="text-indigo-900">Avg. Stress</p>
                    <p className="font-medium">
                      {Math.round(stressData.reduce((acc, curr) => acc + curr.level, 0) / stressData.length)}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <Brain className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Stress Assessment</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <Waves className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Breathing Exercises</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <Timer className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Meditation</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <Music className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Ambient Sounds</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <HeartPulse className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Mood Tracking</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <Calendar className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Journal</span>
              </button>
              <button className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                <span className="text-indigo-900">Progress Report</span>
              </button>
            </div>
            
            {/* Current Exercise Timer */}
            {currentExercise && exerciseTimer && (
              <div className="mt-6 bg-white p-4 rounded-lg shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-indigo-900">{currentExercise.name}</h3>
                  <Clock className="w-4 h-4 text-indigo-600" />
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-1000"
                    style={{
                      width: `${(exerciseTimer / currentExercise.duration) * 100}%`,
                    }}
                  />
                </div>
                <p className="text-sm text-indigo-900 mt-2">
                  {Math.floor(exerciseTimer / 60)}:{(exerciseTimer % 60).toString().padStart(2, '0')} remaining
                </p>
              </div>
            )}

            {/* Ambient Sound Controls */}
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-indigo-900 mb-2">Ambient Sounds</h3>
              <div className="grid grid-cols-2 gap-2">
                {ambientSounds.map(sound => {
                  const Icon = sound.icon;
                  return (
                    <button
                      key={sound.id}
                      onClick={() => toggleAmbientSound(sound.id)}
                      className={`p-2 rounded-lg flex items-center justify-center ${
                        ambientSound === sound.id
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white text-indigo-600 hover:bg-indigo-50'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Stress Level Chart */}
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-indigo-900 mb-2">Stress Trends</h3>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <Line data={chartData} options={chartOptions} />
              </div>
            </div>
          </div>

          {/* Chat Interface */}
          <div className="col-span-2 flex flex-col">
            {/* Chat Header */}
            <div className="bg-indigo-600 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="w-6 h-6" />
                <div>
                  <h1 className="text-xl font-semibold">AI Stress Management Assistant</h1>
                  <p className="text-xs text-indigo-200">Available 24/7 for support</p>
                </div>
              </div>
              {userProfile && (
                <button
                  onClick={() => setShowProfile(!showProfile)}
                  className="p-2 hover:bg-indigo-700 rounded-full transition-colors"
                >
                  <Settings className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Messages Container */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.sender === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`flex items-start gap-2 max-w-[80%] ${
                      message.sender === 'user' ? 'flex-row-reverse' : ''
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        message.sender === 'user'
                          ? 'bg-indigo-100 text-indigo-600'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {message.sender === 'user' ? (
                        <User className="w-5 h-5" />
                      ) : (
                        <Bot className="w-5 h-5" />
                      )}
                    </div>
                    <div
                      className={`rounded-lg p-3 ${
                        message.sender === 'user'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-line">{message.text}</p>
                      {message.type === 'feedback' && message.sender === 'bot' && (
                        <div className="mt-2 flex gap-2">
                          {[1, 2, 3, 4, 5].map((rating) => (
                            <button
                              key={rating}
                              onClick={() => setInputMessage(rating.toString())}
                              className="p-2 hover:bg-indigo-100 rounded transition-colors"
                            >
                              {rating}
                            </button>
                          ))}
                        </div>
                      )}
                      <p className="text-xs mt-1 opacity-70">
                        {format(message.timestamp, 'h:mm a')}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Form */}
            <form
              onSubmit={handleSendMessage}
              className="p-4 border-t border-gray-200 bg-gray-50"
            >
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 transition-colors duration-200 flex items-center gap-2"
                  disabled={!inputMessage.trim()}
                >
                  <Send className="w-4 h-4" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;